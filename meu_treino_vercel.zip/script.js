
// Rolar até os objetivos
document.getElementById('comecar').addEventListener('click', () => {
  document.querySelector('.objetivos').scrollIntoView({ behavior: 'smooth' });
});

// Atualizar os exercícios com base no objetivo
document.querySelectorAll('.objetivo').forEach((botao) => {
  botao.addEventListener('click', () => {
    const objetivo = botao.textContent;

    const exercicios = {
      'Perder Peso': {
        imagem: 'esteira.png',
        texto: 'Esteira 30 min + Circuito Funcional'
      },
      'Ganhar Massa': {
        imagem: 'supino.png',
        texto: 'Supino Reto<br>4 Séries x 8-10 Reps'
      },
      'Definir': {
        imagem: 'corda.png',
        texto: 'Pular Corda + Abdominais'
      }
    };

    const card = document.querySelector('.card');
    card.querySelector('img').src = exercicios[objetivo].imagem;
    card.querySelector('img').alt = objetivo;
    card.querySelector('p').innerHTML = exercicios[objetivo].texto;
  });
});

// SALVAR PROGRESSO
function salvarProgresso() {
  const checkboxes = document.querySelectorAll('.diario input[type="checkbox"]');
  const estado = {};
  checkboxes.forEach((checkbox, index) => {
    estado[index] = checkbox.checked;
  });
  localStorage.setItem('progressoTreino', JSON.stringify(estado));
}

// CARREGAR PROGRESSO
function carregarProgresso() {
  const estado = JSON.parse(localStorage.getItem('progressoTreino')) || {};
  const checkboxes = document.querySelectorAll('.diario input[type="checkbox"]');
  checkboxes.forEach((checkbox, index) => {
    checkbox.checked = estado[index] || false;
    checkbox.parentElement.style.color = checkbox.checked ? 'lime' : '';
  });
}

// SALVAR DATA DO TREINO
function registrarDataTreino() {
  const hoje = new Date();
  const data = hoje.toISOString().split('T')[0]; // yyyy-mm-dd
  let datas = JSON.parse(localStorage.getItem('datasTreino')) || [];
  if (!datas.includes(data)) {
    datas.push(data);
    localStorage.setItem('datasTreino', JSON.stringify(datas));
  }
  gerarGrafico();
}

// CHECKBOX EVENT
document.querySelectorAll('.diario input[type="checkbox"]').forEach((checkbox) => {
  checkbox.addEventListener('change', () => {
    checkbox.parentElement.style.color = checkbox.checked ? 'lime' : '';
    salvarProgresso();
    if (checkbox.checked) registrarDataTreino();
  });
});

// GERAR GRÁFICO
function gerarGrafico() {
  const datas = JSON.parse(localStorage.getItem('datasTreino')) || [];
  const dias = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
  const counts = [0, 0, 0, 0, 0, 0, 0];

  datas.forEach(data => {
    const dia = new Date(data).getDay();
    counts[dia]++;
  });

  const ctx = document.getElementById('graficoTreino').getContext('2d');
  if (window.meuGrafico) window.meuGrafico.destroy(); // evita sobreposição
  window.meuGrafico = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: dias,
      datasets: [{
        label: 'Treinos por dia da semana',
        data: counts,
        backgroundColor: 'rgba(255, 99, 132, 0.7)'
      }]
    },
    options: {
      scales: {
        y: { beginAtZero: true, stepSize: 1 }
      }
    }
  });
}

// INICIAR
window.addEventListener('DOMContentLoaded', () => {
  carregarProgresso();
  gerarGrafico();
});
